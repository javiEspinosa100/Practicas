﻿CREATE TABLE [dbo].[Roles]
(
    [Id] INT PRIMARY KEY IDENTITY(1,1),
    [Name] NVARCHAR(255) NOT NULL
);
