﻿CREATE TABLE [dbo].[Users]
(
    [Id] INT PRIMARY KEY IDENTITY(1,1),
    [UserName] NVARCHAR(20) NOT NULL,
    [Email] NVARCHAR(30) NOT NULL,
    [PasswordHash] NVARCHAR(255) NOT NULL,
    [PasswordSalt] NVARCHAR(255) NOT NULL,
    [FirstName] NVARCHAR(20) NOT NULL,
    [LastName] NVARCHAR(20) NOT NULL,
    [CreateDate] DATE NOT NULL,
    [LockDate] DATE NOT NULL,
    

);


