﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using UserManager.Data.Configurations;
using UserManager.Data.Repositories;

namespace UserManager.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            
            var serviceProvider = new ServiceCollection()
                .AddDbContext<AppDbContext>(options =>
                    options.UseSqlServer("Server=(localDB)\\MSSQLLocalDB;Database=master;Trusted_Connection=True;"))
                .BuildServiceProvider();

            AppDbContext _context=serviceProvider.GetRequiredService<AppDbContext>();

            UserRepository _userRepository = new UserRepository(_context);

            System.Console.WriteLine("Bienvenido");

            //leer readline
        }
    }
}
