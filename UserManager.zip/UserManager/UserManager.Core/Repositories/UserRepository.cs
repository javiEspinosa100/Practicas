﻿using UserManager.Core.Entities;
using UserManager.Core.Repositories;
using UserManager.Data.Configurations;

namespace UserManager.Data.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;

        public UserRepository(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Obtiene todos los usuarios de la base de datos.
        /// </summary>
        /// <returns>Una lista de usuarios.</returns>
        public IEnumerable<Users> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        /// <summary>
        /// Obtiene un usuario por su ID.
        /// </summary>
        /// <param name="id">El ID único del usuario.</param>
        /// <returns>El usuario con el ID especificado.</returns>
        public Users GetUserByEmail(string email)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == email);
            if (user == null)
                throw new Exception("Usuario no encontrado");

            return user;
        }

        /// <summary>
        /// Agrega un nuevo usuario a la base de datos.
        /// </summary>
        /// <param name="user">El objeto de tipo <see cref="Users"/> que representa el usuario a agregar.</param>
        public void AddUser(Users user)
        {
            //dar de alta roles
            _context.Users.Add(user);
            _context.SaveChanges();

        }

        /// <summary>
        /// Actualiza la información de un usuario existente en la base de datos.
        /// </summary>
        /// <param name="user">El objeto de tipo <see cref="Users"/> con la nueva información del usuario.</param>
        public void UpdateUser(Users user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }

        /// <summary>
        /// Elimina un usuario de la base de datos.
        /// </summary>
        /// <param name="id">El ID único del usuario a eliminar.</param>
        public void DeleteUser(string email)
        {
            var user = _context.Users.FirstOrDefault(u=>u.Email==email);
            if (user != null)
            {
                var roles = _context.UserRoles.Where(u => u.UserId == user.Id).ToList();
                if (roles.Any())
                {
                    //remove range elimina una lista, remove solo elimina uno
                    _context.UserRoles.RemoveRange(roles);
                }
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }
    }
}

