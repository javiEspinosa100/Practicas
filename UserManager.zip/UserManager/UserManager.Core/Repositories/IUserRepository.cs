﻿using UserManager.Core.Entities;

namespace UserManager.Core.Repositories
{
    public interface IUserRepository
    {
        /// <summary>
        /// Extrae todos los usuarios
        /// </summary>
        /// <returns></returns>
        IEnumerable<Users> GetAllUsers();

        /// <summary>
        /// Extrae un usuario por email
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        Users GetUserByEmail(string email);

        /// <summary>
        /// Añade un usuario
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        void AddUser(Users user);

        /// <summary>
        /// Actualizara un usuario
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        void UpdateUser(Users user);

        /// <summary>
        /// Borrara un usuario por email
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        void DeleteUser(string email);
    }
}
