﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManager.Core.Entities
{
    public class UserRole
    {
        public int UserId { get; set; }
        public required Users User { get; set; }

        public int RoleId { get; set; }
        public required Roles Role { get; set; }
    }
}
