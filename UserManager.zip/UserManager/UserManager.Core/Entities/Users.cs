﻿using System.ComponentModel.DataAnnotations;

namespace UserManager.Core.Entities
{
    public class Users
    {
        public int Id { get; set; }

        [Required]
        [StringLength(20)]
        public required string UserName { get; set; }

        [Required]
        public required string Email { get; set; }
        public required string PasswordHash { get; set; }
        public required string PasswordSalt { get; set; }
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime LockDate { get; set; }

        public List<UserRole> UserRole { get; set; }

    }
}

