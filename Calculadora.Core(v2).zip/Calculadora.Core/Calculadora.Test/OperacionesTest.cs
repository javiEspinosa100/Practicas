using Calculadora.App.Controllers;
using Calculadora.App.Models;
using Calculadora.Core.Interfaces;
using Calculadora.Core.Services;
using Microsoft.AspNetCore.Mvc;
namespace Calculadora.Test
{
    public class OperacionesTest
    {
        /// <summary>
        /// Prueba unitaria para verificar el comportamiento de la funci�n de divisi�n cuando el divisor es cero.
        /// En este caso, se espera que el controlador devuelva un mensaje de error indicando que no se puede dividir entre cero.
        /// </summary>
        [Fact]
        public void Test_Dividir_Entre_Cero()
        {
            var calculadora = new OperacionModel
            {
                NumeroUno = 10,
                NumeroDos = 0,
                Operacion = "Divisi�n"
            };
            var service = new OperacionesService();

            var controller =new HomeController(service);

            var result=controller.Index(calculadora);

            var viewResult=result as ViewResult;    //Como devuelve un ActionResult, podemos hacer casting a ViewResult ( un action result devuelve una accion con una vista)
            string errorMessages = viewResult.ViewData["Error"].ToString();     //Extraemos el mensaje de error del action result y lo pasamos a string
            Assert.Equal("No se puede dividir entre cero.", errorMessages); //Comparamos si el error que nos devuelve el throw de la excepcion es el que debe ser

        }
    }
}