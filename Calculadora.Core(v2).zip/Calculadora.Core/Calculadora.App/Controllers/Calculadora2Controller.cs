﻿using Calculadora.Core.Interfaces;
using Calculadora.Core.Models;
using Microsoft.AspNetCore.Mvc;

namespace Calculadora.App.Controllers
{
    public class Calculadora2Controller : Controller
    {
        private readonly IOperacionesService _operacionesService;

        private static List<OperacionHistorial> _historial = new List<OperacionHistorial>();

        /// <summary>
        /// INYECCIÓN DE DEPENDENCIAS
        /// </summary>
        /// <param name="operacionesService"></param>
        public Calculadora2Controller(IOperacionesService operacionesService)
        {
            _operacionesService = operacionesService;
        }
        public IActionResult Calcular()
        {

            return View("Index");
        }

        /// <summary>
        /// Este método recibe un modelo que contiene una cadena de operación, la analiza para identificar dos operandos y un operador,
        /// realiza la operación aritmética solicitada y almacena el resultado en un historial. Además, maneja cualquier excepción
        /// que pueda surgir, incluyendo la división por cero, y devuelve una vista con el resultado o un mensaje de error.
        /// </summary>
        /// <param name="modelo">El modelo que contiene la cadena de operación y los datos adicionales para procesar el cálculo.</param>
        /// <returns>Devuelve la vista "Index", que incluye el resultado del cálculo o un mensaje de error.</returns>
        [HttpPost]
        public IActionResult Calcular(Calculadora2 modelo)
        {
            decimal resultado = 0;
            try
            {
                char operador = modelo.Operacion.FirstOrDefault(c => "+-*/".Contains(c));

                string[] numerosStr = modelo.Operacion.Split(operador);

                if (numerosStr.Length != 2)
                {
                    ViewBag.Resultado = "Solo se aceptan operaciones de dos números.";
                    return View("Index");
                }
                decimal numeroUno = Convert.ToDecimal(numerosStr[0].Trim());
                decimal numeroDos = Convert.ToDecimal(numerosStr[1].Trim());

                //Realiza la operacion matematica correspondiente con los dos numeros y el operador,
                //el switch se ha llevado al servicio
                resultado = _operacionesService.RealizarOperacion(numeroUno, numeroDos, operador);

                string operacion = $"{numeroUno} {operador} {numeroDos}";

                _historial.Add(new OperacionHistorial
                {
                    Operacion = operacion,
                    Resultado = resultado
                });

                ViewBag.Resultado = resultado;

                return View("Index");
            }
            catch (DivideByZeroException)
            {
                ViewBag.Resultado = "No se puede dividir entre cero.";
            }
            catch (Exception ex)
            {
                ViewBag.Resultado = ex.Message;
            }

            return View("Index");
        }

        /// <summary>
        /// Este método devuelve una vista que muestra el historial de operaciones realizadas previamente.
        /// </summary>
        /// <returns>Devuelve la vista "Historico" con el historial de operaciones.</returns>
        public IActionResult DameHistorico()
        {
            return View("Historico", _historial);
        }

    }
}
