﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Core.Models
{
    public class OperacionHistorial
    {
        /// <summary>
        /// Operacion sera en si la cuenta ha realizar, ejemplo: 2+2
        /// </summary>
        public string Operacion { get; set; }

        /// <summary>
        /// Resultado sera el resultado de la operacion anterior en este caso: 4
        /// </summary>
        public decimal Resultado { get; set; }
    }
}
