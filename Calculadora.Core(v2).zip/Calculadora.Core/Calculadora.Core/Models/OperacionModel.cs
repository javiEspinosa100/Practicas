﻿using System.ComponentModel.DataAnnotations;

namespace Calculadora.Core.Models
{
    public class OperacionModel
    {
        /// <summary>
        /// Primer numero de la operacion
        /// </summary>
        [Required(ErrorMessage = "El número 1 es obligatorio.")]
        public decimal NumeroUno { get; set; }


        /// <summary>
        /// Segundo numero de la operacion
        /// </summary>
        [Required(ErrorMessage = "El número 2 es obligatorio.")]
        public decimal NumeroDos { get; set; }

        /// <summary>
        /// Operación que se va a realizar
        /// </summary>
        [Required(ErrorMessage = "Debe seleccionar una operación.")]
        public char Operacion { get; set; }
    }
}
