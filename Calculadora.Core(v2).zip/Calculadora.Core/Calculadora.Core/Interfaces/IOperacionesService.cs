﻿namespace Calculadora.Core.Interfaces
{
    public interface IOperacionesService
    {

        /// <summary>
        /// Método que le llegará la operacion a realizar Suma, Resta, Division o Multiplicación y los dos numeros y realizara las operaciones
        /// </summary>
        /// <param name="num1">Número 1</param>
        /// <param name="num2">Número 2</param>
        /// <param name="operacion">Operacion a realizar</param>
        /// <returns></returns>
        decimal RealizarOperacion(decimal num1, decimal num2, char operacion);





    }
}
