﻿namespace Calculadora.Core
{
    public class Class1
    {

    }
}
