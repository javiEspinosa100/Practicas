﻿using Calculadora.Core.Interfaces;
using Calculadora.Core.Models;
using Microsoft.AspNetCore.Mvc;

namespace Calculadora.App.Controllers
{
    public class Calculadora2Controller : Controller
    {
        private readonly IOperacionesService _operacionesService;
        private static List<OperacionHistorial> _historial = new List<OperacionHistorial>();

        public Calculadora2Controller(IOperacionesService operacionesService)
        {
            _operacionesService = operacionesService;
        }
        public IActionResult Calcular()
        {

            return View("Index");
        }

        [HttpPost]
        public IActionResult Calcular(Calculadora2 modelo)
        {
            decimal resultado = 0;
            try
            {
                char operador = modelo.Operacion.FirstOrDefault(c => "+-*/".Contains(c));

                string[] numerosStr = modelo.Operacion.Split(operador);

                decimal numeroUno = Convert.ToDecimal(numerosStr[0].Trim());
                decimal numeroDos = Convert.ToDecimal(numerosStr[1].Trim());

                resultado = _operacionesService.RealizarOperacion(numeroUno, numeroDos, operador);

                string operacion = $"{numeroUno} {operador} {numeroDos}";

                _historial.Add(new OperacionHistorial
                {
                    Operacion = operacion,
                    Resultado = resultado
                });
                ViewBag.Resultado = resultado;
                return View("Index");
            }
            catch (DivideByZeroException)
            {
                ViewBag.Error = "No se puede dividir entre cero.";
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }


            return View("Index");
        }

        public IActionResult DameHistorico()
        {

            return View("Historico", _historial);
        }

    }
}
