using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Calculadora.Core.Interfaces;

using System.Globalization;
using Calculadora.Core.Models;

namespace Calculadora.App.Controllers;

public class HomeController : Controller
{
    private readonly IOperacionesService _operacionesService;

    public HomeController(IOperacionesService operacionesService)
    {
        _operacionesService = operacionesService;
    }

    public IActionResult Index()
    {
        return View();
    }

    /// <summary>
    /// Realiza una operaci�n matem�tica basada en los valores proporcionados en el modelo.
    /// </summary>
    /// <param name="modelo">El modelo que contiene los n�meros y la operaci�n a realizar.</param>
    /// <returns>Devuelve la vista con el resultado de la operaci�n o un mensaje de error en caso de excepci�n.</returns>
    /// <exception cref="InvalidOperationException">Se lanza si la operaci�n proporcionada no es v�lida.</exception>
    [HttpPost]
    public IActionResult Index(OperacionModel modelo)
    {
        decimal resultado = 0;
        try
        {
            resultado = _operacionesService.RealizarOperacion(modelo.NumeroUno, modelo.NumeroDos, modelo.Operacion);
            ViewBag.Resultado = resultado;
            return View();
        }
        catch (DivideByZeroException)
        {
            ViewBag.Error = "No se puede dividir entre cero.";
            return View();
        }
        catch (Exception ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

}
