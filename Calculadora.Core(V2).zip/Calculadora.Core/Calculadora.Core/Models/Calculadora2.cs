﻿using System.ComponentModel.DataAnnotations;

namespace Calculadora.Core.Models
{
    public class Calculadora2
    {
        /// <summary>
        ///Representa la operación que se debe realizar.
        /// Esta propiedad es obligatoria y debe ser proporcionada por el usuario.
        /// </summary>
        [Required(ErrorMessage = "La operación es obligatoria.")]
        public string Operacion { get; set; }

       



    }
}
