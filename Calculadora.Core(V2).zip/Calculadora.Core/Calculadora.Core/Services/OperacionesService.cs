﻿using Calculadora.Core.Interfaces;

namespace Calculadora.Core.Services
{
    public class OperacionesService : IOperacionesService
    {
        /// <summary>
        /// Método para sumar
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>La suma de los dos números</returns>
        private static decimal Sumar(decimal num1, decimal num2) 
            => num1 + num2;

        /// <summary>
        /// Método para restar
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>La resta de los dos números</returns>
        private static decimal Restar(decimal num1, decimal num2) 
            => num1 - num2;

        /// <summary>
        /// Método para multiplicar
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>El producto de los dos números</returns>
        private static decimal Multiplicar(decimal num1, decimal num2) 
            => num1 * num2;

        /// <summary>
        /// Método para dividir
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>El cociente de la división</returns>
        /// <exception cref="DivideByZeroException">Lanzada si se intenta dividir entre cero</exception>
        private static decimal Dividir(decimal num1, decimal num2)
        {
            if (num2 == 0)
            {
                throw new DivideByZeroException("No se puede dividir entre cero.");
            }
            return num1 / num2;
        }

        /// <summary>
        /// Método para realizar una operación matemática entre dos números
        /// </summary>
        /// <param name="num1">Primer número</param>
        /// <param name="num2">Segundo número</param>
        /// <param name="operacion">Tipo de operación (Suma, Resta, Multiplicación, División)</param>
        /// <returns>El resultado de la operación</returns>
        /// <exception cref="DivideByZeroException">Lanzada si se intenta dividir entre cero</exception>
        public decimal RealizarOperacion(decimal num1, decimal num2, char operacion)
        {
            switch (operacion)
            {
                case '+':
                    return Sumar(num1, num2);
                case '-':
                    return Restar(num1, num2);
                case '*':
                    return Multiplicar(num1, num2);
                case '/':
                    return Dividir(num1, num2);
                default:
                    throw new InvalidOperationException("Operación no válida");
            }
        }

    }
}
