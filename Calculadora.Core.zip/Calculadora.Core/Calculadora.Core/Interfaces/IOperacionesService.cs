﻿namespace Calculadora.Core.Interfaces
{
    public interface IOperacionesService
    {
        /// <summary>
        /// Método para sumar dos números
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns></returns>
        decimal Sumar(decimal num1, decimal num2);

        /// <summary>
        /// Método para restar dos números
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns></returns>
        decimal Restar(decimal num1, decimal num2);

        /// <summary>
        /// Método para multiplicar dos números
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns></returns>
        decimal Multiplicar(decimal num1, decimal num2);

        /// <summary>
        /// Método para dividir dos números
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <returns></returns>
        decimal Dividir(decimal num1, decimal num2);


    }
}
