﻿using Calculadora.Core.Interfaces;

namespace Calculadora.Core.Services
{
    public class OperacionesService : IOperacionesService
    {
        /// <summary>
        /// Método para sumar
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>La suma de los dos números</returns>
        public decimal Sumar(decimal num1, decimal num2) 
            => num1 + num2;

        /// <summary>
        /// Método para restar
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>La resta de los dos números</returns>
        public decimal Restar(decimal num1, decimal num2) 
            => num1 - num2;

        /// <summary>
        /// Método para multiplicar
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>El producto de los dos números</returns>
        public decimal Multiplicar(decimal num1, decimal num2) 
            => num1 * num2;

        /// <summary>
        /// Método para dividir
        /// </summary>
        /// <param name="num1">Primer numero</param>
        /// <param name="num2">Segundo numero</param>
        /// <returns>El cociente de la división</returns>
        /// <exception cref="DivideByZeroException">Lanzada si se intenta dividir entre cero</exception>
        public decimal Dividir(decimal num1, decimal num2)
        {
            if (num2 == 0)
            {
                throw new DivideByZeroException("No se puede dividir entre cero.");
            }
            return num1 / num2;
        }
    }
}
