using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Calculadora.App.Models;
using Calculadora.Core.Interfaces;
using System.Globalization;

namespace Calculadora.App.Controllers;

public class HomeController : Controller
{
    private readonly IOperacionesService _operacionesService;

    public HomeController(IOperacionesService operacionesService)
    {
        _operacionesService = operacionesService;
    }

    public IActionResult Index()
    {
        return View();
    }

    /// <summary>
    /// Realiza una operaci�n matem�tica basada en los valores proporcionados en el modelo.
    /// </summary>
    /// <param name="modelo">El modelo que contiene los n�meros y la operaci�n a realizar.</param>
    /// <returns>Devuelve la vista con el resultado de la operaci�n o un mensaje de error en caso de excepci�n.</returns>
    /// <exception cref="InvalidOperationException">Se lanza si la operaci�n proporcionada no es v�lida.</exception>
    [HttpPost]
    public IActionResult Index(OperacionModel modelo)
    {
        decimal resultado = 0;
        try
        { 
            switch (modelo.Operacion)
            {
                case "Suma":
                    resultado = _operacionesService.Sumar(modelo.NumeroUno, modelo.NumeroDos);
                    break;
                case "Resta":
                    resultado = _operacionesService.Restar(modelo.NumeroUno, modelo.NumeroDos);
                    break;
                case "Multiplicaci�n":
                    resultado = _operacionesService.Multiplicar(modelo.NumeroUno, modelo.NumeroDos);
                    break;
                case "Divisi�n":
                    resultado = _operacionesService.Dividir(modelo.NumeroUno, modelo.NumeroDos);
                    break;
                default:
                    throw new InvalidOperationException("Operaci�n no v�lida");
            }
            ViewBag.Resultado = resultado;
            return View();
        }
        catch (DivideByZeroException)
        {
            ViewBag.Error = "No se puede dividir entre cero.";
            return View();
        }
        catch (Exception ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
