using Calculadora.App.Controllers;
using Calculadora.App.Models;
using Calculadora.Core.Interfaces;
using Calculadora.Core.Services;
using Microsoft.AspNetCore.Mvc;
namespace Calculadora.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test_Dividir_Entre_Cero()
        {
            var calculadora = new OperacionModel
            {
                NumeroUno = 10,
                NumeroDos = 0,
                Operacion = "Divisi�n"
            };
            var service = new OperacionesService();

            var controller =new HomeController(service);

            var result=controller.Index(calculadora);

            var viewResult=result as ViewResult;
            var errorMessages = viewResult.ViewData["Error"] as string[];
            Assert.Contains("No se puede dividir entre cero.", errorMessages[0]);

        }
    }
}